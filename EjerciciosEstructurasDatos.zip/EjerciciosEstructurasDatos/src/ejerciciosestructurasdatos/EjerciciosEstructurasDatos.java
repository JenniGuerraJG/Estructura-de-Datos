/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciosestructurasdatos;

import java.util.Scanner;

/**
 *
 * @author ESPE
 */
public class EjerciciosEstructurasDatos {

    public static void main(String[] args) {
        Scanner scann = new Scanner(System.in);
        int menu;
        do{
        System.out.println("-------------------------------------------------------");
        System.out.println("          UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE");
        System.out.println("Nombre: Guerra Jennifer ");
        System.out.println("Curso: 3ero ITIN  ");
        System.out.println("Fecha: 17/05/2024");
        System.out.println("Tema: Ejercicios Recursividad");
        System.out.println("-------------------------------------------------------");
        System.out.println("-------------------------------------------------------");
        System.out.println("Ingrese opcion que desee: ");
        System.out.println("0. Salir");
        System.out.println("-- Recursividad");
        System.out.println("1. método que imprima los dígitos desde 1 hasta “n” ");
        System.out.println("2. Obtener longitud del numero y caracter ");
        System.out.println("3. Invertir numeros ");
        System.out.println("4. Calcular la potencia de un numero ");
        System.out.println("-- ArrayList: ");
        System.out.println("5. Elementos de un ArrayList");
        System.out.println("6. Pilas ");
        System.out.println("-------------------------------------------------------");
        menu = scann.nextInt();
        
        switch(menu){
            case 0:
                System.out.println("Ha salido del programa...");
                break;
            case 1:
                
                Ejercicios E1= new Ejercicios();
                E1.PedirDatos();
            case 2:    
                 Ejercicios E2= new Ejercicios();
                 E2.PedirDatos2();
            break;
            case 3:
                System.out.println("Ingrese el numero positivo hasta el cual desea imprimir");
                int n = scann.nextInt();
               Ejercicios E3= new Ejercicios();
                  System.out.println(E3.invertirRecursivamente(n,0));
                  break;
            case 4:
                System.out.println("Ingrese el numero positivo hasta el cual desea imprimir");
                int a = scann.nextInt();
               Ejercicios E4= new Ejercicios();
               System.out.println(E4.potenciajja(a));
               break;
            case 5:
                Ejercicios E5= new Ejercicios();
                E5.arraylist();
                break;
            case 6:
                Ejercicios E6= new Ejercicios();
                E6.insertarPila ();
                break;
            default:
                System.out.println("ERROR INGRESE UN VALOR VALIDO");
                
        }
        }while(menu != 0);
    }
    
}
