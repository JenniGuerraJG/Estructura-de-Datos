
package ejerciciosestructurasdatos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Stack;

public class Ejercicios {
     Scanner scann = new Scanner(System.in);
    
    public void PedirDatos(){
        
       System.out.println("Ingrese el numero positivo hasta el cual desea imprimir");
       int n = scann.nextInt();
       while( n <= 0){
           System.out.println("Solo numeros positivos");
       }
       System.out.println("-------------------------------------------------------");
       System.out.println("Incremento: ");
       incre( n);
       System.out.println("-------------------------------------------------------");
       System.out.println("Decremento: ");
       decre(n);
    }
    
    public void PedirDatos2(){
        System.out.println("Inserte una cadena de caracteres: ");
        String cadena= scann.nextLine();
       String cade = cadena.replaceAll("[^\\dA-Za-z]", "");
        int contador = 0;
      System.out.println(contarcaracteres(cade,cade.length() ));
       
       
       
       System.out.println("Ingrese el numero positivo hasta el cual desee obtener su longitud");
       int n = scann.nextInt();
       while( n <= 0){
           System.out.println("Solo numeros positivos");
       }
  
          System.out.println(digi(n));
       System.out.println("-------------------------------------------------------");
       
       
    }
    
    public void incre(int n) {
    if(n>0)
    {
        incre(n-1);
        System.out.print(n);
        System.out.println("    ");
    }
    
}
    
     public void decre(int n) {
    if(n>0)
    {
        System.out.println(n);
        decre(n-1);
        
        System.out.println("    ");
    }
    
   
}

     public int digi(int n)
{
    if(n<=0) return 0;
    return 1 + digi(n/10);
}
     
     int contarcaracteres(String cadena,int contador){
        int n;     
        if(contador!=0){
        
             contarcaracteres(cadena,contador-1);
             n = +1;
             
        }else{
            n = contador;
        }
     
         return contador;
     }
     
    public  int invertirRecursivamente(int n, int invertido) {
        if (n == 0) {
            return invertido;
        }
        int resto = n % 10;
        invertido = invertido * 10 + resto;
        return invertirRecursivamente(n / 10, invertido);
    }

    public int potenciajja (int n){
        
        return(n*n);
    }
            
    public void arraylist(){
        
        ArrayList<String> nombreArrayList = new ArrayList<String>();
        String elementoBuscado= " ";
        // Añadimos 10 Elementos en el ArrayList
        for (int i=0; i<=10; i++){
                nombreArrayList.add("Elemento "+i); 
        }

        // Añadimos un nuevo elemento al ArrayList en la posición 2
        nombreArrayList.add(2, "Elemento 3");

        // Declaramos el Iterador e imprimimos los Elementos del ArrayList
        Iterator<String> nombreIterator = nombreArrayList.iterator();
        while(nombreIterator.hasNext()){
                String elemento = nombreIterator.next();
                System.out.println(elemento+" / ");
        }
        int numeroTotal = contarArreglo (nombreArrayList, 0);
         System.out.println(numeroTotal);
         repeticionElemento (nombreArrayList);
         eliminar( nombreArrayList);
         agg (nombreArrayList);
    }
    
    int contarArreglo (ArrayList<String> nombreArrayList, int contador){
            
        if (contador == nombreArrayList.size()){
            return 0;
        }else{
            return 1 + contarArreglo(nombreArrayList, contador+1);
        }
        
    }
    
    public void repeticionElemento (ArrayList<String> nombreArrayList){
         boolean encontrado = false; 
         String elementoBuscado = " ";
        for (int i = 0; i < nombreArrayList.size(); i++) {
             elementoBuscado = nombreArrayList.get(i);

            for (int j = i + 1; j < nombreArrayList.size(); j++) {
                if (elementoBuscado.equals(nombreArrayList.get(j))) {
                    encontrado = true;
                    System.out.println("Se encontraron elementos iguales en el ArrayList: " + elementoBuscado + " y se ha eliminado");
                    nombreArrayList.remove(elementoBuscado);
                        for(String elemento : nombreArrayList ){
                            System.out.println(nombreArrayList);
                           break;
                        }
                    break; 
                }
            }
          if (encontrado) {
                break; 
            }
        }
         if(!encontrado){
                 
                 System.out.println("No se encontraron elementos iguales en el arrayList");

         }
    }
    
     public  void eliminar(ArrayList<String> nombreArrayList) {
        System.out.println("Ingrese el elemento que desee eliminar:");
        String elementoBuscado = scann.nextLine();
        boolean encontrado = false;

        for (int i = 0; i < nombreArrayList.size(); i++) {
            if (elementoBuscado.equals(nombreArrayList.get(i))) {
                nombreArrayList.remove(i);
                encontrado = true;
                break;
            }
        }

        if (encontrado) {
            System.out.println("Elemento eliminado: " + elementoBuscado);
        } else {
            System.out.println("Elemento no encontrado en el ArrayList.");
        }

        System.out.println("ArrayList después de la eliminación:");
        for (String elemento : nombreArrayList) {
            System.out.println(elemento);
        }
    }
     
     public void agg (ArrayList<String> nombreArrayList){
         System.out.println("Ingrese el elemento que desee agregar:");
         String elementoAgregar = scann.nextLine();
         for (int i = 0; i < nombreArrayList.size(); i++) {
            
             nombreArrayList.add(elementoAgregar);
             break;
                          
        }
         
          System.out.println("ArrayList después de agregar: "+ elementoAgregar);
        for (String elemento : nombreArrayList) {
            System.out.println(elemento);
        }
     }
     
     public void insertarPila (){
         System.out.println("Igrese el numero a convertir:");
         int n = scann.nextInt();
         binario(n);
         String numeroStr = String.valueOf(n);
         invertir(numeroStr);
     }
     
      static void binario(int numero) {
        Stack<Integer> pila = new Stack<>();

        // Manejar el caso en que el número es 0
        if (numero == 0) {
            System.out.println("El número en binario es: 0");
            return;
        }

        // Convertir el número a binario usando la pila
        while (numero > 0) {
            int resto = numero % 2;
            pila.push(resto);
            numero = numero / 2;
        }

        // Desapilar y mostrar los restos, que forman el número en binario
        System.out.print("El número en binario es: ");
        while (!pila.isEmpty()) {
            System.out.print(pila.pop());
        }
        System.out.println();  // Para una nueva línea después del resultado
    }
     
     static void invertir(String s) {
    var pila = new Stack<Character>();
    // Insertar las letras en la pila
    for (int i = 0; i < s.length(); i++) {
        pila.push(s.charAt(i));
    }
    // Al desapilarlos, ir mostrando la cadena al reves
    while (!pila.empty()) {
        System.out.print(pila.pop());
    }
}

}


